/*
 This scripts tries to simulate an offloading in VANETs environment;

 The main steps are:
                    1º CONSUMER start the discovery to perform the offloading;
                    2º Surrogates replies the requests;
                    3º CONSUMER sends the data to the surrogates
                    4º Surrogates process the tasks and send it back;
                    5º CONSUMER received the processed tasks.

 Authors:
        Mateus Sousa (UFBA)

NOTE: Is necessary to perform more tests

*/
#include "offloading-app.hpp"
#include "ns3/ptr.h"
#include "ns3/log.h"
#include "ns3/simulator.h"
#include "ns3/packet.h"
#include "ns3/callback.h"
#include "ns3/string.h"
#include "ns3/boolean.h"
#include "ns3/uinteger.h"
#include "ns3/integer.h"
#include "ns3/double.h"
#include "ns3/ndnSIM/helper/ndn-stack-helper.hpp"

NS_LOG_COMPONENT_DEFINE("ns3::ndn::Offloading");

namespace ns3{
namespace ndn{
NS_OBJECT_ENSURE_REGISTERED(Offloading);

TypeId
Offloading::GetTypeId(){
        static TypeId tid = TypeId("ns3::ndn::Offloading")
        .SetParent<ndn::App>()
        .AddConstructor<Offloading>()
        .AddAttribute("producer","Act as a server",BooleanValue(false),MakeBooleanAccessor(&Offloading::isServer),
                       MakeBooleanChecker())
         .AddAttribute("PayloadSize", "Virtual payload size for Content packets", UintegerValue(1024),
                       MakeUintegerAccessor(&Offloading::pktLentgh),
                       MakeUintegerChecker<uint32_t>())
         .AddAttribute("surrogates", "Number of surrogates needed", UintegerValue(2),
                       MakeUintegerAccessor(&Offloading::numberOfSurrogates),
                       MakeUintegerChecker<uint32_t>())
         .AddAttribute("pTime", "Processing time according to the length of the matrix", DoubleValue(0.857),
                     MakeDoubleAccessor(&Offloading::processingTime),
                     MakeDoubleChecker<double>())

        ;

        return tid;
}

// Constructor
Offloading::Offloading()
  :isServer(false) // Is a PRODUCER or a CONSUMER?
  ,pktLentgh(1024) // packet length
  ,offladSuccess(0) // Offloading count
  ,numberOfSurrogates(0) // Total of surrogates needed
  , processingTime(0.857) // Processing time according to the length of the matrix
{
  NS_LOG_FUNCTION_NOARGS();
}

Offloading::~Offloading()
{
}

void
Offloading::StartApplication(){
    // initialize ndn::App
    ndn::App::StartApplication();
    // (GetNode()->GetId());
    // Waking up the server
    Simulator::Schedule(MilliSeconds(0), &Offloading::Server,this);
    // Here is the initial step (the service discovering)
    Simulator::Schedule(MilliSeconds(50), &Offloading::SendInterest, this);
}

void
Offloading::StopApplication()
{
  // cleanup ndn::App
  ndn::App::StopApplication();
}


void
Offloading::SendInterest(){
  if (!isServer) {
    NS_LOG_UNCOND("[CONSUMER] Starting discovery...");
    // Send interest packet looking for computation services
    auto interest = std::make_shared<ndn::Interest>("/computation");
    // Ptr<UniformRandomVariable> rand = CreateObject<UniformRandomVariable>();
    // interest->setNonce(rand->GetValue(0, std::numeric_limits<uint32_t>::max()));
    interest->setInterestLifetime(ndn::time::seconds(1));
    // Call trace (for logging purposes) (blablabla)
    m_transmittedInterests(interest, this, m_face);
    m_appLink->onReceiveInterest(*interest);

  }else{
        auto interest = std::make_shared<ndn::Interest>("/data");
        interest->setInterestLifetime(ndn::time::seconds(1));

        NS_LOG_UNCOND("[PRODUCER] Requesting task... ");
        m_transmittedInterests(interest, this, m_face);
        m_appLink->onReceiveInterest(*interest);
  }
}

void
Offloading::OnInterest(std::shared_ptr<const ndn::Interest> interest){
  ndn::App::OnInterest(interest);

  // Note that Interests send out by the app will not be sent back to the app !
  auto data = std::make_shared<ndn::Data>(interest->getName());
  data->setFreshnessPeriod(ndn::time::milliseconds(1000));
  data->setContent(std::make_shared< ::ndn::Buffer>(pktLentgh));
  // If node is CONSUMER then send the packet with the tasks,
  // otherwise send a reply packet

  if (!isServer && interest->getName() == "/data"){
          NS_LOG_UNCOND("[CONSUMER] Sending the task to the surrogate...");

          ndn::StackHelper::getKeyChain().sign(*data);
          m_transmittedDatas(data, this, m_face);
          m_appLink->onReceiveData(*data);

          // Tell to the PRODUCER to process the task
          Simulator::Schedule(MilliSeconds(10),&Offloading::Process,this);
  }
  else if(isServer && interest->getName() == "/process" ){
        // TODO: implement the processing delay for the tasks
        NS_LOG_UNCOND("[PRODUCER] Sending the results...");
        ndn::StackHelper::getKeyChain().sign(*data);
        // NS_LOG_UNCOND("[PRODUCER] Sending data packet for " << data->getName());

        m_transmittedDatas(data, this, m_face);
        m_appLink->onReceiveData(*data);

  }

  else
  {
      NS_LOG_UNCOND("[PRODUCER] Sending reply...");
      data->setContent(std::make_shared< ::ndn::Buffer>(100));
      ndn::StackHelper::getKeyChain().sign(*data);
      m_transmittedDatas(data, this, m_face);
      m_appLink->onReceiveData(*data);
      // Requesting the task
      Simulator::Schedule(MilliSeconds(0),&Offloading::SendInterest,this);
  }
}

void
Offloading::OnData(std::shared_ptr<const ndn::Data> data)
{

  if (!isServer && data->getName() == "/process") {
      NS_LOG_UNCOND("[CONSUMER] Receiving data packet for " << data->getName() << " length : "
      << data->getSignature().getValue().value_size());
      offladSuccess++;
      if (offladSuccess == numberOfSurrogates) {
          NS_LOG_UNCOND("\n[INFO] Offloading successfully completed =)\n");
      }
  }
  else if (!isServer && data->getName() == "/computation") {
          NS_LOG_UNCOND("[CONSUMER] Received one reply for " << data->getName() );
          // Now I'm a producer (to send the tasks)
          FibHelper::AddRoute(GetNode(), "/data", m_face, 0);

  }

  else
  {
        // TODO: implement
        NS_LOG_UNCOND("[PRODUCER] Task received "<< data->getName() << ". Processing...");
        // After received the task listen for the 'process' signal
        FibHelper::AddRoute(GetNode(), "/process", m_face, 0);
  }
}

// Server Side
void
Offloading::Server(void){
      if (isServer) {
        NS_LOG_UNCOND("Node "<< GetNode()->GetId() << " is a PRODUCER");
        // Insert the prefix in the FIB
        FibHelper::AddRoute(GetNode(), "/computation", m_face, 0);

      }else{
            NS_LOG_UNCOND("Node "<< GetNode()->GetId() << " is a CONSUMER");
      }
}

// Called by the CONSUMER to send the 'process' signal to the producer
void
Offloading::Process(void) {
  if (!isServer) {
    auto interest = std::make_shared<ndn::Interest>("/process");
    interest->setInterestLifetime(ndn::time::seconds(1));
    // Call trace (for logging purposes) (blablabla)
    m_transmittedInterests(interest, this, m_face);
    m_appLink->onReceiveInterest(*interest);
  }
}

}
}
