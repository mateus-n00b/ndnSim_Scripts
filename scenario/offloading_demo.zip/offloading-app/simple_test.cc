#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include "ns3/packet.h"

namespace ns3{
      int main(int argc, char *argv[]) {

        // LogComponentEnable("ndn.Consumer",LOG_LEVEL_INFO);
        LogComponentEnable("CustomApp",LOG_LEVEL_DEBUG);

        NodeContainer nodes;
        nodes.Create(3);

        // PHY
        PointToPointHelper p2p;
        p2p.Install(nodes.Get(0),nodes.Get(1));
        p2p.Install(nodes.Get(1),nodes.Get(2));

        // NETWORK STACK
        ndn::StackHelper ndnHelper;
        ndnHelper.SetDefaultRoutes(true) ;
        ndnHelper.InstallAll();

        ndn::StrategyChoiceHelper::InstallAll("/prefix", "/localhost/nfd/strategy/multicast");

        ndn::AppHelper consumer("ns3::ndn::Offloading");
        // consumer.SetAttribute("server", BooleanValue(true));
        consumer.Install(nodes.Get(0));


        // auto interest = std::make_shared<ndn::Interest>("/prefix/sub");

        // ndn::AppHelper producer ("ns3::ndn::Producer");                        
        ndn::AppHelper producer ("ns3::ndn::Offloading");
        // producer.SetPrefix("/computation");
        producer.SetAttribute("server", BooleanValue(true));
        producer.Install(nodes.Get(2));


        ndn::AppDelayTracer::Install(nodes.Get(0),"app-delays-trace.txt");
        // consumer.SendPacket();
        Simulator::Stop(Seconds(20));
        Simulator::Run();
        Simulator::Destroy();
        return 0;
        }
  }

  int
  main(int argc, char* argv[])
  {
    return ns3::main(argc, argv);
  }
