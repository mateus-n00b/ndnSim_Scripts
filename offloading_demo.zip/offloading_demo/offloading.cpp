/*
 This scripts tries to simulate an offloading in VANETs environment

 Authors:
        Mateus Sousa (UFBA)

NOTE: --

*/

#include "offloading.hpp"
#include "ns3/ptr.h"
#include "ns3/log.h"
#include "ns3/simulator.h"
#include "ns3/packet.h"
#include "ns3/callback.h"
#include "ns3/string.h"
#include "ns3/boolean.h"
#include "ns3/uinteger.h"
#include "ns3/integer.h"
#include "ns3/double.h"
#include "ns3/ndnSIM/helper/ndn-stack-helper.hpp"

NS_LOG_COMPONENT_DEFINE("ns3::ndn::Offloading");

namespace ns3{
namespace ndn{
NS_OBJECT_ENSURE_REGISTERED(Offloading);

TypeId
Offloading::GetTypeId(){
        static TypeId tid = TypeId("ns3::ndn::Offloading")
        .SetParent<ndn::App>()
        .AddConstructor<Offloading>()
        .AddAttribute("server","Act as a server",BooleanValue(false),
         MakeBooleanAccessor(&Offloading::isServer),MakeBooleanChecker())
        ;

        return tid;
}

// Constructor
Offloading::Offloading(): isServer(false)
{
  NS_LOG_FUNCTION_NOARGS();
}

Offloading::~Offloading()
{
}

void
Offloading::StartApplication(){
    // initialize ndn::App
    ndn::App::StartApplication();

    // Waking up the server
    Simulator::Schedule(MilliSeconds(99), &Offloading::Server,this);
    // Here is the start point (the service discovering)
    Simulator::Schedule(MilliSeconds(100), &Offloading::Discover, this);

}

void
Offloading::Discover(){
  auto interest = std::make_shared<ndn::Interest>("/computation");
  // Ptr<UniformRandomVariable> rand = CreateObject<UniformRandomVariable>();
  // interest->setNonce(rand->GetValue(0, std::numeric_limits<uint32_t>::max()));
  // interest->setInterestLifetime(ndn::time::seconds(1));

  NS_LOG_DEBUG("Sending Interest packet for " << *interest);

  // Call trace (for logging purposes) (blablabla)
  m_transmittedInterests(interest, this, m_face);

  m_appLink->onReceiveInterest(*interest);
}

void
Offloading::StopApplication()
{
  // cleanup ndn::App
  ndn::App::StopApplication();
}

void
Offloading::OnInterest(std::shared_ptr<const ndn::Interest> interest){
  ndn::App::OnInterest(interest);

  NS_LOG_DEBUG("Received Interest packet for " << interest->getName());

  // Note that Interests send out by the app will not be sent back to the app !

  auto data = std::make_shared<ndn::Data>(interest->getName());
  data->setFreshnessPeriod(ndn::time::milliseconds(1000));
  data->setContent(std::make_shared< ::ndn::Buffer>(1024));
  ndn::StackHelper::getKeyChain().sign(*data);

  NS_LOG_DEBUG("Sending Data packet for " << data->getName());

  // Call trace (for logging purposes)
  m_transmittedDatas(data, this, m_face);

  m_appLink->onReceiveData(*data);
}

void
Offloading::OnData(std::shared_ptr<const ndn::Data> data)
{
  NS_LOG_DEBUG("Receiving Data packet for " << data->getName());
  std::cout << "DATA received for name " << data->getName() << std::endl;

  if (data->getName() == "/computation/reply" ) {
      // TODO: implement
      NS_LOG_UNCOND("HELLO");
  }
  else {
        // TODO: implement
        NS_LOG_UNCOND("HELLO OTHER");
  }
}

void
Offloading::Server(){
      if (isServer) {
        NS_LOG_UNCOND("IS SERVER");
      }else{
        NS_LOG_UNCOND("IS NOT A SERVER");
      }
}

}
}
