// My header

#ifndef OFFLOADING_H
#define OFFLOADING_H

#include "ns3/ndnSIM/model/ndn-common.hpp"
#include "ns3/ndnSIM/apps/ndn-app.hpp"

namespace ns3{
namespace ndn{
  class Offloading : public ndn::App{
    public:
          static TypeId
          GetTypeId();

          Offloading();
          virtual ~Offloading();

          virtual void
          StartApplication();

          // (overridden from ndn::App) Processing when application is stopped
          virtual void
          StopApplication();

          // (overridden from ndn::App) Callback that will be called when Interest arrives
          virtual void
          OnInterest(std::shared_ptr<const ndn::Interest> interest);

          // (overridden from ndn::App) Callback that will be called when Data arrives
          virtual void
          OnData(std::shared_ptr<const ndn::Data> contentObject);

    protected:
          void
          Discover();
          void
          Server();

          bool isServer;

  };
}
}

#endif
